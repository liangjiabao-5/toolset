import requests
import sys

# 发送GET请求
response = requests.get(sys.argv[1])
print(response.text)